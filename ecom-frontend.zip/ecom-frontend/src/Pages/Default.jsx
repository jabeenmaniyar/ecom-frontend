import React from 'react'
import Navbar from '../components/Navbar'
import Landing from '../components/LandingPage'

function Default() {
    return (
        <div>
            <Landing />
        </div>
    )
}

export default Default
